from django.apps import AppConfig


class WeeddetectConfig(AppConfig):
    name = 'weeddetect'
